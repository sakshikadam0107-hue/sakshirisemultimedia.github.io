window.SAKSHI_CONFIG = {
  // Paste your published Google Form URL between the quotes.
  googleFormUrl: "YOUR_GOOGLE_FORM_URL"
};

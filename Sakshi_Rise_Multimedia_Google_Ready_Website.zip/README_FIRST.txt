# Sakshi Rise Multimedia — Google-Ready Website

## Included
- `index.html` — main website
- `assets/sakshi-rise-logo.png` — Sakshi Rise Multimedia logo
- `config.js` — Google Form connection setting
- `robots.txt` — crawler-friendly starter file
- `sitemap.xml` — replace YOUR-DOMAIN before submitting to Search Console

## IMPORTANT BEFORE PUBLIC LAUNCH
1. Replace `YOUR_GOOGLE_FORM_URL` in `config.js` with your official Google Form URL.
2. Replace `YOUR_PUBLISHED_WEBSITE_URL` in the JSON-LD inside `index.html` with your real published URL.
3. If Google Search Console gives you an HTML verification tag, place it in the `<head>` where the comment indicates.
4. Replace `YOUR-DOMAIN` in `sitemap.xml` and `robots.txt` after you have your real domain.
5. Add your final Privacy Policy, Terms & Conditions and Refund/Cancellation policy pages before taking public payments.
6. Do not claim government recognition, accreditation, awards, testimonials or business registrations unless they are genuine and completed.

## Google publishing order
Website files -> publish online -> open the real HTTPS URL -> Google Search Console -> URL prefix -> verify -> URL Inspection -> Request Indexing -> submit sitemap after the real domain is configured.

A local `file:///C:/.../index.html` address cannot appear in Google Search results.
